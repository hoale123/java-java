package com.company.Customer.Data.Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
