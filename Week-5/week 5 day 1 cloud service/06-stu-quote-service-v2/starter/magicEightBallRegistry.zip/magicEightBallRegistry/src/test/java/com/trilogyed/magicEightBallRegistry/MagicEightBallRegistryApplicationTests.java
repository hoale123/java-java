package com.trilogyed.magicEightBallRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagicEightBallRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
