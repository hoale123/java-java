package com.trilogyed.magicEightBallRegistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagicEightBallRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagicEightBallRegistryApplication.class, args);
	}

}
