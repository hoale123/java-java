package com.twou.rsvp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RsvpServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
