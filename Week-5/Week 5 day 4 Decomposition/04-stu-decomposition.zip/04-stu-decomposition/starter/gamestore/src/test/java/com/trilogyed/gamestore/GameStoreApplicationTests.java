package com.trilogyed.gamestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
